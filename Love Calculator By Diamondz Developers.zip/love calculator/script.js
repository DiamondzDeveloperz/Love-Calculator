
	function lovepercentage() {
		var data = Math.random() * 100;
		data = Math.floor(data);
		document.getElementById('result').value = data + "%";
	}